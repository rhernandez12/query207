USE `alertasx`;

LOAD DATA CONCURRENT INFILE '/server207/alertasx_alertas_consultas.csv' IGNORE INTO TABLE alertasx.alertas_consultas FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/server207/alertasx_alertas_edificio.csv' IGNORE INTO TABLE alertasx.alertas_edificio FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/server207/alertasx_alertas_edificio_c.csv' IGNORE INTO TABLE alertasx.alertas_edificio_c FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/server207/alertasx_alerta_edificio_sw.csv' IGNORE INTO TABLE alertasx.alerta_edificio_sw FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;
